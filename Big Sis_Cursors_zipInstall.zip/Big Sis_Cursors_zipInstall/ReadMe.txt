Creator: 滅Q (MiyQ)

Twitter (X): @Qlc2ioQ  
Link: https://x.com/Qlc2ioQ

Size: 64x64 pixels

Cursor Character: Tsukishima Shijima (from Shimeji Simulation)

Cursor Type: Static

Two versions are included:

1. With White Border
2. Without Border

How to Install:

1. Right-click on the install.inf file, and select "Install" from the menu.
2. Click "Yes" when prompted.
3. Then click "OK".

After it's completed, the cursor's appearance will change.

------------------------------------------------------------------------------------------------------------------

This is the hardest drawing I've ever done

If you like it, please share it with friends who enjoy "Shimeji Simulation"

The next one I'm going to draw is Mogawa-sensei

------------------------------------------------------------------------------------------------------------------

If you want to share this cursor with others,  
**please share the complete file package**.

Strictly prohibited:  
- Commercial use  
- Use in AI training

------------------------------------------------------------------------------------------------------------------

Below is some rambling:

If you're interested, feel free to check out the website

Holy shit, I'm seriously addicted to oh-my-pi Ｏ(≧▽≦)Ｏ

https://miyq02.github.io/